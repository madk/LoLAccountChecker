import os, sys, urllib, urllib2, json

version_url = 'https://ddragon.leagueoflegends.com/api/versions.json'

def loadJsonFromUrl(url):
	r = urllib2.urlopen(url)
	str_r = r.read().decode('utf-8')
	return json.loads(str_r)

obj = loadJsonFromUrl(version_url)
versions = []
for i in range(5):
    versions.append(obj[i].encode('utf-8'))
latest_version = versions[0]

print 'Available versions:'
print versions
print ''
print 'Choose version'
print '(if null will return latest version)'
print ''

champs_version = raw_input('Champions: ')
images_version = raw_input('Images: ')
runes_version = raw_input('Runes: ')

versions = [champs_version, images_version, runes_version]

for i in range(len(versions)):
    if not versions[i]:
        versions[i] = latest_version

base_url = 'http://ddragon.leagueoflegends.com/cdn/'
champs_url = '%s%s/data/en_US/championFull.json' % (base_url, versions[0])
img_url = '%s%s/img/champion/' % (base_url, versions[1])
runes_url = '%s%s/data/en_US/rune.json' %(base_url, versions[2])

print ''
print 'Please wait...'
print ''

obj = loadJsonFromUrl(champs_url)

output = []

for ck, champion in sorted(obj['data'].items()):
    skins = []

    for skin in champion['skins']:
        skins.append({'Id': int(skin['id']), 'Name': skin['name'], 'Num': skin['num']})

    output.append({'Id': int(champion['key']), 'StrId': champion['id'], 'Name': champion['name'], 'Skins': skins})

    print(champion['name'])


with open('Champions.json', 'w') as f:
	json.dump(output, f)

with open('Champions.Version', 'w') as f:
	f.write(versions[0])

if not os.path.exists('images'):
	os.makedirs('images')

for champion in output:
	filename = champion['StrId'] + '.png'
	
	url = img_url + filename
	
	filepath = os.path.join('images', filename)
	
	urllib.urlretrieve(url, filepath)
	
	print 'Downloading image for champion ' + champion['Name']

with open('Images.Version', 'w') as f:
	f.write(versions[1])

def getRuneType(str_type):
	type = {
		'red':		1,
		'yellow':	2,
		'blue':		3,
		'black':	4
	}
	return type[str_type] if str_type in type else 0


obj = loadJsonFromUrl(runes_url)

output = []

for rune_id in obj['data']:
	rune = {
		'Id':			int(rune_id),
		'Name':			obj['data'][rune_id]['name'],
		'Description':	obj['data'][rune_id]['description'],
		'Tier': 		int(obj['data'][rune_id]['rune']['tier']),
		'Type':			getRuneType(obj['data'][rune_id]['rune']['type'])
	}
	output.append(rune)
	
	print rune['Name']

with open('Runes.json', 'w') as f:
	json.dump(output, f)

with open('Runes.Version', 'w') as f:
	f.write(versions[2])

print ''
print 'Press Enter to continue...' 
raw_input()
